# Assembly notes (draft, update after build)

## Tools
Allen keys (M3/M5), small screwdriver, soldering iron, flush cutters, ruler/calipers, 3D printer.

## Order
1. **Print** all parts (PLA/PETG, 0.2 mm, 20-30% infill). Test-fit bearings and rods before assembling.
2. **Prepare base board** (about 36 × 42 cm). Mark mounting holes from the frame model.
3. **Y axis:** fit the 300 mm linear rail, then mount the Y motor and belt path with the idler.
4. **X axis:** slide the 8 mm rods through the 45 mm bearings on the carriage; mount the X motor and belt.
5. **Pen carriage:** 25 mm bearing + 5.5 cm rod, servo mount, pen holder.
6. **Limit switches:** one at the X home end, one at the Y home end.
7. **Electronics:** mount the PCB, fit the TMC2208 drivers, wire motors, servo, switches and fan.
8. **Belts:** tension until there is no slack but the carriage moves freely.
9. **Power and test:** follow `firmware/README.md`.

## Safety
- Never plug or unplug stepper motors while powered; it can destroy drivers.
- Check the 12 V polarity before connecting.
- Keep fingers clear of the belts during homing.
