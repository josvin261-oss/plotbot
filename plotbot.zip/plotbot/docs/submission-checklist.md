# Fallen submission checklist

## README.md
- [ ] What it is and how to use it
- [ ] Why I made it (my own words)
- [ ] Screenshot: full 3D assembly
- [ ] Screenshot: PCB
- [ ] Screenshot: schematic / wiring diagram
- [ ] 3D render (optional)
- [ ] All `TODO`s removed

## Repository
- [ ] `.step` file for every modeled part (`cad/step/`)
- [ ] Source assembly (`.f3d`, `.FCStd` or Onshape link), incl. electronics
- [ ] KiCad: `.kicad_pro`, `.kicad_sch`, `.kicad_pcb`, `.kicad_prl`
- [ ] `gerbers.zip`
- [ ] Firmware (`firmware/`; untested is OK for a design submission)
- [ ] `bom.csv` with a link for every item (mention items already owned)
- [ ] Repo is **public**

## Build submission only
- [ ] Demo video linked in README
- [ ] Photos of the finished product
- [ ] Source files updated to match what was built

Questions: ask in #fallen on the Hack Club Slack.
