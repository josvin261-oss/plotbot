# SVG → G-code (Inkscape)

PlotBot expects G-code where **pen up = `M5`** and **pen down = `M3 S<value>`** (servo on the spindle PWM pin).

## Option A: use the inspiration project's extension
The DIY Machines repo ships an *MI Inkscape Extension* for this exact workflow:
<https://github.com/DIY-Machines/CNC-DrawingMachine/tree/master/MI%20Inkscape%20Extension>

1. Copy the extension files into Inkscape's user extensions folder (*Edit → Preferences → System → User extensions*).
2. Restart Inkscape.
3. Draw or import an SVG, convert text to paths (*Path → Object to Path*), keep it inside the drawing area.
4. *Extensions → (extension name) → Export G-code*.
5. Check that pen-up/down commands are `M5` / `M3 S...` and the units are mm.

## Option B: any SVG→G-code tool
Tools such as `svg2gcode` or the *Gcodetools* extension work if you set the pen commands to `M5` (up) / `M3 S<value>` (down) and add a small dwell (`G4 P0.2`) after each so the servo finishes moving.

## Sending
Use Universal G-code Sender, Candle or bCNC at 115200 baud. Always home (`$H`) first, then set work zero at the paper corner.

> Licence note: this repo does not copy the DIY Machines files; link to them or add them with their licence if you vendor them.
