# Firmware

PlotBot runs on an **Arduino Uno + CNC shield** (2 × TMC2208, servo pen-lift, 2 limit switches).

> **Status:** design submission, untested on hardware. Values are starting points to tune after the build.

There are two ways to run it:

| Option | When to use |
|---|---|
| **A. `plotbot/plotbot.ino`** (included, my own code) | Simplest. One sketch, no libraries besides `Servo`. |
| **B. GRBL 1.1 + servo fork** (e.g. DIY Machines' `grbl-mi`) | If you want GRBL features (acceleration, `$` settings). See `grbl-config/grbl-settings.txt`. |

## Option A: flash `plotbot.ino`

1. Open `firmware/plotbot/plotbot.ino` in the Arduino IDE.
2. Select **Arduino Uno** and the right port, then upload.
3. Open the Serial Monitor at **115200 baud**, line ending "Newline". You should see `PlotBot ready.`
4. Tune the constants at the top of the sketch (steps/mm, travel, pen angles, axis directions).

### Pin mapping (CNC shield v3 on Uno)

| Function | Uno pin | Shield header |
|---|---|---|
| X STEP / DIR | D2 / D5 | X driver |
| Y STEP / DIR | D3 / D6 | Y driver |
| Driver ENABLE | D8 | shared |
| X limit switch | D9 | X endstop (to GND) |
| Y limit switch | D10 | Y endstop (to GND) |
| Servo signal | D11 | Z+ |

### Supported commands
`G0/G1 X Y F`, `G4 P`, `G20/G21`, `G28` or `$H` (home), `G90/G91`, `G92 X Y`, `M3 [S angle]` (pen down), `M5` (pen up), `M17/M18` (motors on/off), `M114` (report position).

### First tests
1. Send `M114`; you should get `X:0.000 Y:0.000 homed:0`.
2. Hold each limit switch and confirm homing stops. Send `$H`. If an axis goes the wrong way, flip `INVERT_*_DIR` or `HOME_*_SIGN`.
3. `G91` then `G1 X10 F1000`; measure the move. If it isn't 10 mm, fix `STEPS_PER_MM_X/Y`.
4. `M3` and `M5`: tune `PEN_DOWN_ANGLE` / `PEN_UP_ANGLE` so the pen just touches the paper.
5. `G90`, then plot a 50 mm square and check that it closes.

## Option B: GRBL

1. Add a servo-capable GRBL 1.1 fork as an Arduino library and upload `grblUpload`.
2. Send each line of [`grbl-config/grbl-settings.txt`](grbl-config/grbl-settings.txt) at 115200 baud.
3. Same pins as above (GRBL defaults); servo on the spindle PWM pin D11 (`M3`/`M5`).

## Generating G-code
See [`inkscape-extension/README.md`](inkscape-extension/README.md). Pen up = `M5`, pen down = `M3`.
