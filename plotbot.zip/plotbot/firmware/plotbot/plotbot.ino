/*
 * PlotBot firmware: 2-axis pen plotter for Arduino Uno + CNC shield
 * (2 stepper drivers, servo pen-lift, 2 limit switches).
 *
 * Reads G-code over USB serial (115200 baud) and replies "ok" per line.
 * Status: written for the design submission, UNTESTED on hardware.
 *
 * Supported G-code:
 *   G0 / G1  X Y F   linear move (G0 = rapid)
 *   G4 P<ms>         dwell
 *   G20 / G21        accepted, always millimetres
 *   G28 or $H        home X and Y (toward the limit switches)
 *   G90 / G91        absolute / relative positioning
 *   G92 X Y          set current position
 *   M3 [S<angle>]    pen down (optional servo angle)
 *   M5               pen up
 *   M17 / M18        motors on / off
 *   M114             report position
 *   M2 / M30         accepted, no-op
 *   (Inkscape-style output with M3 S.../M5 works as is.)
 */

#include <Servo.h>

// ---------------- Pins (Arduino CNC shield v3 on Uno) ----------------
const uint8_t X_STEP = 2, Y_STEP = 3;
const uint8_t X_DIR  = 5, Y_DIR  = 6;
const uint8_t EN_PIN = 8;          // LOW = drivers enabled
const uint8_t X_LIM  = 9, Y_LIM = 10;   // switch to GND, internal pull-up
const uint8_t SERVO_PIN = 11;      // Z+ header on the shield

// ---------------- Machine settings (TUNE THESE) ----------------
// 200 steps/rev * 16 microsteps / (20 teeth * 2 mm GT2 pitch) = 80 steps/mm
const float STEPS_PER_MM_X = 80.0;
const float STEPS_PER_MM_Y = 80.0;
const float MAX_X_MM = 200.0;      // travel limits (soft limits)
const float MAX_Y_MM = 250.0;
const float DEFAULT_FEED = 1500.0; // mm/min
const float MAX_FEED     = 3000.0; // mm/min
const float HOME_FEED    = 600.0;  // mm/min
const float HOME_BACKOFF = 2.0;    // mm
const unsigned long MIN_STEP_US = 150;  // fastest allowed step interval

// Flip these if an axis moves the wrong way / homes the wrong way
const bool INVERT_X_DIR = false;
const bool INVERT_Y_DIR = false;
const int  HOME_X_SIGN  = -1;      // -1 = switch at the minimum end
const int  HOME_Y_SIGN  = -1;

// Servo pen lift (degrees)
const int PEN_UP_ANGLE   = 90;
const int PEN_DOWN_ANGLE = 40;
const unsigned long PEN_MOVE_MS = 250;

// ---------------- State ----------------
Servo pen;
long posX = 0, posY = 0;           // current position in steps
bool absoluteMode = true;
float feedRate = DEFAULT_FEED;     // mm/min
bool homed = false;

char lineBuf[96];
uint8_t lineLen = 0;

// ---------------- Helpers ----------------
void setDirX(bool positive) { digitalWrite(X_DIR, (positive != INVERT_X_DIR) ? HIGH : LOW); }
void setDirY(bool positive) { digitalWrite(Y_DIR, (positive != INVERT_Y_DIR) ? HIGH : LOW); }

void pulse(uint8_t pin) {
  digitalWrite(pin, HIGH);
  delayMicroseconds(4);
  digitalWrite(pin, LOW);
}

void penUp()   { pen.write(PEN_UP_ANGLE);   delay(PEN_MOVE_MS); }
void penDown(int angle) { pen.write(angle); delay(PEN_MOVE_MS); }

// Returns true and sets 'out' if letter 'c' is present in the line.
bool getValue(const char *line, char c, float &out) {
  for (const char *p = line; *p; p++) {
    if (*p == c) { out = atof(p + 1); return true; }
  }
  return false;
}

// ---------------- Motion ----------------
// Move in a straight line to target (steps). Bresenham, constant speed.
void moveTo(long tx, long ty, float feed) {
  // Soft limits (only meaningful once homed)
  if (homed) {
    long maxX = (long)(MAX_X_MM * STEPS_PER_MM_X);
    long maxY = (long)(MAX_Y_MM * STEPS_PER_MM_Y);
    tx = constrain(tx, 0, maxX);
    ty = constrain(ty, 0, maxY);
  }
  long dx = tx - posX, dy = ty - posY;
  long adx = abs(dx), ady = abs(dy);
  long n = max(adx, ady);
  if (n == 0) return;

  feed = constrain(feed, 10.0, MAX_FEED);
  float lenMM = sqrt(sq((float)dx / STEPS_PER_MM_X) + sq((float)dy / STEPS_PER_MM_Y));
  // time per dominant-axis step, in microseconds
  float intervalUs = (lenMM / (float)n) * 60.0e6 / feed;
  if (intervalUs < MIN_STEP_US) intervalUs = MIN_STEP_US;

  setDirX(dx >= 0);
  setDirY(dy >= 0);
  delayMicroseconds(10);

  long errX = n / 2, errY = n / 2;
  unsigned long next = micros();
  for (long i = 0; i < n; i++) {
    errX += adx;
    errY += ady;
    if (errX >= n) { errX -= n; pulse(X_STEP); }
    if (errY >= n) { errY -= n; pulse(Y_STEP); }
    next += (unsigned long)intervalUs;
    while ((long)(micros() - next) < 0) { /* wait */ }
  }
  posX = tx;
  posY = ty;
}

// Move one axis until its limit switch is hit, then back off and zero it.
void homeAxis(bool isX) {
  uint8_t stepPin = isX ? X_STEP : Y_STEP;
  uint8_t limPin  = isX ? X_LIM  : Y_LIM;
  float spm = isX ? STEPS_PER_MM_X : STEPS_PER_MM_Y;
  int sign  = isX ? HOME_X_SIGN : HOME_Y_SIGN;
  float maxMM = (isX ? MAX_X_MM : MAX_Y_MM) + 20.0;
  unsigned long us = (unsigned long)(60.0e6 / (HOME_FEED * spm));

  if (isX) setDirX(sign > 0); else setDirY(sign > 0);
  delayMicroseconds(10);
  long limit = (long)(maxMM * spm);
  long i = 0;
  while (digitalRead(limPin) == HIGH && i < limit) {   // HIGH = not pressed
    pulse(stepPin);
    delayMicroseconds(us);
    i++;
  }
  // back off
  if (isX) setDirX(sign < 0); else setDirY(sign < 0);
  delayMicroseconds(10);
  long back = (long)(HOME_BACKOFF * spm);
  for (long j = 0; j < back; j++) { pulse(stepPin); delayMicroseconds(us); }
}

void homeAll() {
  penUp();
  homeAxis(true);
  homeAxis(false);
  posX = 0;
  posY = 0;
  homed = true;
}

// ---------------- G-code handling ----------------
void reportPos() {
  Serial.print(F("X:")); Serial.print((float)posX / STEPS_PER_MM_X, 3);
  Serial.print(F(" Y:")); Serial.print((float)posY / STEPS_PER_MM_Y, 3);
  Serial.print(F(" homed:")); Serial.println(homed ? 1 : 0);
}

void handleLine(char *line) {
  // strip ';' comments and '(...)' comments, uppercase
  for (char *p = line; *p; p++) {
    if (*p == ';' || *p == '(') { *p = 0; break; }
    *p = toupper(*p);
  }
  // skip leading spaces
  while (*line == ' ') line++;
  if (*line == 0) { Serial.println(F("ok")); return; }

  if (line[0] == '$') {
    if (line[1] == 'H') { homeAll(); }
    Serial.println(F("ok"));
    return;
  }

  float g, m, v;
  if (getValue(line, 'G', g)) {
    int gi = (int)g;
    if (gi == 0 || gi == 1) {
      float f;
      if (getValue(line, 'F', f)) feedRate = f;
      float curX = (float)posX / STEPS_PER_MM_X;
      float curY = (float)posY / STEPS_PER_MM_Y;
      float tx = curX, ty = curY;
      if (getValue(line, 'X', v)) tx = absoluteMode ? v : curX + v;
      if (getValue(line, 'Y', v)) ty = absoluteMode ? v : curY + v;
      float useFeed = (gi == 0) ? MAX_FEED * 0.6 : feedRate;
      moveTo(lround(tx * STEPS_PER_MM_X), lround(ty * STEPS_PER_MM_Y), useFeed);
    } else if (gi == 4) {
      if (getValue(line, 'P', v)) delay((unsigned long)v);
    } else if (gi == 28) {
      homeAll();
    } else if (gi == 90) {
      absoluteMode = true;
    } else if (gi == 91) {
      absoluteMode = false;
    } else if (gi == 92) {
      if (getValue(line, 'X', v)) posX = lround(v * STEPS_PER_MM_X);
      if (getValue(line, 'Y', v)) posY = lround(v * STEPS_PER_MM_Y);
    }
    // G20/G21 and others: accepted, ignored
  } else if (getValue(line, 'M', m)) {
    int mi = (int)m;
    if (mi == 3) {
      float s;
      int angle = PEN_DOWN_ANGLE;
      // Treat S as a servo angle only if it is a plausible angle (0-180)
      if (getValue(line, 'S', s) && s >= 0 && s <= 180) angle = (int)s;
      penDown(angle);
    } else if (mi == 5) {
      penUp();
    } else if (mi == 17) {
      digitalWrite(EN_PIN, LOW);
    } else if (mi == 18) {
      digitalWrite(EN_PIN, HIGH);
    } else if (mi == 114) {
      reportPos();
    }
    // M2 / M30 / others: accepted, ignored
  }
  Serial.println(F("ok"));
}

// ---------------- Arduino entry points ----------------
void setup() {
  pinMode(X_STEP, OUTPUT); pinMode(Y_STEP, OUTPUT);
  pinMode(X_DIR, OUTPUT);  pinMode(Y_DIR, OUTPUT);
  pinMode(EN_PIN, OUTPUT);
  pinMode(X_LIM, INPUT_PULLUP);
  pinMode(Y_LIM, INPUT_PULLUP);
  digitalWrite(EN_PIN, LOW);   // enable drivers

  pen.attach(SERVO_PIN);
  penUp();

  Serial.begin(115200);
  Serial.println(F("PlotBot ready. Send $H or G28 to home."));
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (lineLen > 0) {
        lineBuf[lineLen] = 0;
        handleLine(lineBuf);
        lineLen = 0;
      }
    } else if (lineLen < sizeof(lineBuf) - 1) {
      lineBuf[lineLen++] = c;
    }
  }
}
